"""
MECH2700 Assignment 2: Orion back-shell wall heat transfer (Task 4).
 
Explicit finite-difference solver (forward Euler in time, central differences
in space) for the 2D heat equation on an unwrapped wall strip with:
  - x = 0      : radiative heating/cooling (Neumann)
  - x = h      : convection to cabin air (Neumann)
  - y = 0, L   : periodic
 
Array convention: T[i, j] with i -> x (0 .. nx-1) and j -> y (0 .. ny-1).
Units are SI throughout (m, s, K, W).
"""
import numpy as np

# Problem Constants
RHO = 128.0             # density of AETB-8, kg/m^3
K = 0.0684              # thermal conductivity, W/(m*K)
C = 628.0               # heat capacity, J/(kg*K)
ALPHA = K/(RHO * C)     # thermal diffusivity, m^2/s

H_WALL = 0.038          # wall thickness, m
D_CAPS = 5.0            # capsule diameter, m
L = np.pi * D_CAPS      # unwrappedwall length, m

EPS = 0.873             # TUFI emissivity
Q_IRR = 1361.0          # solar irradiance, W/m^2
SIGMA = 5.67037e-8      # Stefan-Boltzmann constant, W/(m^2*K^4)
H_CONV = 1.5            # inner-wall convection coefficient, W/(m^2*K)
T_AMB = 298.0           # cabin air temperature (and initial wall temperature), K

def make_grid(nx, ny):
    """Return node coordinates x, y and spacings dx, dy."""
    x = np.linspace(0.0, H_WALL, nx)
    y = np.linspace(0.0, L, ny)
    return x, y, x[1]-x[0], y[1]-y[0]

def max_stable_dt(dx, dy):
    """"Von Neumann stability limit: alpha*dt*(1/dx^2 + 1/dy^2) <= 1/2."""
    return 1.0 / (2.0 * ALPHA * (1.0/dx**2 + 1.0/dy**2))

def q_rad(y, t, omega):
    """Absorbed solar flux at positions y and time t (no if statements)."""
    theta = 2.0 *y / D_CAPS - omega *t
    c = np.cos(theta)
    return EPS* Q_IRR * (c + np.abs(c)) / 2.0

def step(T, t, dt, dx, dy, y, omega):
    """
    Advance the temperature field by one explicit time step.
 
    Parameters
    ----------
    T : ndarray (nx, ny)  temperatures at time t
    t : float             current time, s
    dt : float            time step, s
    dx, dy : float        grid spacings, m
    y : ndarray (ny,)     y-coordinates of the nodes, m
    omega : float         capsule rotation rate, rad/s
 
    Returns
    -------
    T_new : ndarray (nx, ny)  temperatures at time t + dt
    """
    rx = ALPHA * dt / dx**2
    ry = ALPHA * dt / dy**2
    T_new = T.copy()

    # Interior nodes (1<= i <= nx-2, 1 <= j <= ny-2)
    T_new[1:-1, 1:-1] =  (rx * (T[2:, 1:-1] + T[:-2, 1:-1]) 
                          + ry * (T[1:-1, 2:] + T[1:-1, :-2]) 
                          + (1.0 - 2.0 * rx - 2.0 * ry) * T[1:-1, 1:-1])

    # x-boundaries new interior:level m+1, old boundary: level m
    # outer surface x=0
    T_new[0,:] = T_new[1,:] + (dx/K)* (q_rad(y, t, omega) - EPS * SIGMA * T[0,:]**4)

    # inner surface x=h
    T_new[-1,:] = T_new[-2,:] - (H_CONV * dx/K) * (T[-1,:] - T_AMB) 

    # periodic y-boundaries 
    T_new[:,-1] = T_new[:,1]
    T_new[:,0] = T_new[:,-2]
    return T_new

def run_simulation(nx, ny, omega, t_max, t_plot, safety=0.9):
    """
    March the solution from t = 0 to t_max.
 
    The time step is chosen as the largest value not exceeding
    safety * dt_max that divides t_max into a whole number of steps.
 
    Returns a dict with:
      x, y         : grid coordinates
      dx, dy, dt   : spacings and time step
      t_snap       : times of the stored snapshots (first step at or after each
                     multiple of t_plot, plus t = 0)
      T_snap       : list of full temperature arrays at those times
      t_hist       : time of every step (including t = 0)
      Tw_max_hist  : max inner-wall temperature at every step
      Tw_min_hist  : min inner-wall temperature at every step
      Tmax_hist    : max temperature anywhere in the domain at every step
      T_final      : final temperature array
    """

    x, y, dx, dy = make_grid(nx, ny)
    dt_limit = safety * max_stable_dt(dx, dy)
    n_steps = int(np.ceil(t_max / dt_limit))
    dt = t_max / n_steps

    T= np.full((nx, ny), T_AMB)  

    t_hist = np.zeros(n_steps + 1)
    Tw_max_hist = np.zeros(n_steps + 1)
    Tw_min_hist = np.zeros(n_steps + 1)
    Tmax_hist = np.zeros(n_steps + 1)

    def record(n, T):
        Tw_max_hist[n] = np.max(T[-1,:])
        Tw_min_hist[n] = np.min(T[-1,:])
        Tmax_hist[n] = np.max(T)

    record(0, T)
    t_snap, T_snap = [0.0], [T.copy()]
    next_plot = t_plot

    for n in range(1, n_steps + 1):
        t = (n-1) * dt
        T = step(T, t, dt, dx, dy, y, omega)
        t_hist[n] = n * dt
        record(n, T)
        if t_hist[n] >= next_plot:
            t_snap.append(t_hist[n])
            T_snap.append(T.copy())
            next_plot += t_plot

    return dict(x=x, y=y, dx=dx, dy=dy, dt=dt, t_snap=t_snap, T_snap=T_snap,
                t_hist=t_hist, Tw_max_hist=Tw_max_hist,
                Tw_min_hist=Tw_min_hist, Tmax_hist=Tmax_hist, T_final=T)

# Test Task 4 (coarse grid, baseline rotation)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    nx = 17                      # dx = h/16
    ny = 159                     # dy ~ 0.1 m, resolves the cos(theta) profile
    omega = 2 * np.pi / 1000.0   # baseline rotation, rad/s
    t_max = 7200.0
    res = run_simulation(nx, ny, omega, t_max, t_plot=t_max / 5)
 
    print(f"dx = {res['dx']:.5f} m, dy = {res['dy']:.4f} m, dt = {res['dt']:.3f} s")
    print(f"dt_max = {max_stable_dt(res['dx'], res['dy']):.3f} s, "
          f"steps = {len(res['t_hist']) - 1}")
    print(f"Snapshots at t = {np.round(res['t_snap'], 1)} s")
    print(f"Max inner-wall temperature at t_max: {res['Tw_max_hist'][-1]:.3f} K")


