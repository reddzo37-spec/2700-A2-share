"""
MECH2700 Assignment 2, Task 6: rotation-rate study.
 
Uses run_simulation() from orion_wall.py on the grid selected in Task 5.
  - omega = 0, baseline (period 1000 s), maximum allowable (period 120 s),
    and a recommended rotation period.
  - Comfort limits: inner wall must stay below 308 K and above 283 K.
  - Material limit: 1870 K anywhere in the wall.
  - Also finds the critical (slowest acceptable) rotation period by bisection.
"""
import numpy as np
import matplotlib.pyplot as plt

import A2_Task_4 as ow

NX, NY =  33, 317
T_MAX = 7200.0
T_HOT, T_COLD, T_MATERIAL = 308.0, 233.0, 1870.0
RECOMMENDED_PERIOD = 600.0 

def omega_from_period(period):
    """Rotation rate (rad/s) for a rotation period in s (None -> no rotation)."""
    return 0.0 if period is None else 2.0 * np.pi / period 

def run_case(period, nx=NX, ny=NY):
    return ow.run_simulation(nx, ny, omega_from_period(period), T_MAX, T_MAX/5)

def summarise(label, period, res):
    """Print the quantities Task 6 asks for and return them in a dict."""
    t, Tmax_w, Tmin_w = res["t_hist"], res["Tw_max_hist"], res["Tw_min_hist"]
    over = Tmax_w > T_HOT
    t_exceed = t[np.argmax(over)] if over.any() else None
    out = dict(label=label, period=period, 
               rpm = 0.0 if period is None else 60/period,
               peak=Tmax_w.max(), t_peak=t[Tmax_w.argmax()],
               t_exceed=t_exceed, low=Tmin_w.min(), 
               domain_max=res["Tmax_hist"].max())
    print(f"{label:<24} RPM={out['rpm']:.4f}  peak Tw,max={out['peak']:.2f} K "
          f"(t={out['t_peak']:.0f} s)  first >308 K: "
          f"{'never' if t_exceed is None else f'{t_exceed:.0f} s'}  "
          f"min Tw={out['low']:.2f} K  max T anywhere={out['domain_max']:.1f} K")
    return out

def critical_period(limit_fn, lo=120.0, hi=2000.0, n_iter=11):
    """
    Bisection for the period at which limit_fn(period) changes sign.
    limit_fn > 0 means the comfort limit is violated. Assumes violation gets
    worse as the period (slower rotation) increases.
    """
    for _ in range(n_iter):
        mid = 0.5 * (lo +hi)
        if limit_fn(mid) > 0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)

def main():
    cases = [("No rotation", None),
             ("Baseline (1000 s)", 1000.0),
             ("Max allowable (120 s)", 120.0),
             (f"Recommended ({RECOMMENDED_PERIOD:.0f} s)", RECOMMENDED_PERIOD)]
    results = {}
    for label, period in cases:
        res = run_case(period)
        results[label] = (period, res, summarise(label, period, res))

     # --- Figure 1: T_w,max histories for all rotation rates ---
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for label, (period, res, _) in results.items():
        ax.plot(res["t_hist"], res["Tw_max_hist"], label=label)
    ax.axhline(T_HOT, color="k", ls="--", lw=1, label="308 K comfort limit")
    ax.set_xlabel("Times (s)")
    ax.set_ylabel(r"$T_{w,max}$ (K)")
    ax.set_title("Maximum inner-wall temperature for differernt rotation rates")
    ax.grid(alpha =0.3)
    ax.legend()
    fig.savefig("task6_Twmax_rotation.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    # --- Figure 2: T_w,min histories (283 K check) ---
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    for label,(period, res, _) in results.items():
        if period is not None:
            ax.plot(res["t_hist"], res["Tw_min_hist"], label = label)
    ax.axhline(T_COLD, color = "k", ls="--", lw=1, label="283 K comfort limit")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel(r"$T_{w,min}$ (K)")
    ax.set_title("Minimum inner-wall temperature for different rotation rates")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.savefig("task6_Twmin_rotation.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    # --- Critical periods and a period scan to justify the recommendation ---
    p_hot = critical_period(lambda P: run_case(P)["Tw_max_hist"].max() - T_HOT)
    p_cold = critical_period(lambda P: run_case(P)["Tw_min_hist"].min())
    print(f"\nCritical period for 308K limit: {p_hot:.0f} s"
          f"({60 / p_hot:.3f} RPM)")
    print(f"\nCritical period for 283K limit: {p_cold:.0f} s"
          f"({60/ p_cold:.3f} RPM)")

    periods = np.array([120, 200, 300, 400, 500, 600, 700, 800, 900, 1000.0])
    peak, low = [], []
    for P in periods:
        r = run_case(P)
        peak.append(r["Tw_max_hist"].max())
        low.append(r["Tw_min_hist"].min())

    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    ax.plot(periods, peak, "o-", label=r"peak $T_{w,max}")
    ax.plot(periods, low, "s-", label=r"lowest $T_{w,min}")
    ax.axhline(T_HOT, color="C0", ls="--", lw=1)
    ax.axhline(T_COLD, color="C1", ls="--", lw=1)
    ax.axvline(120, color="grey", ls=":", label="0.5 RPM limir")
    ax.set_xlabel("Rotation period (s)")
    ax.set_ylabel("Temperature (s)")
    ax.set_title("Inner-wall temperature extremes versus rotation period")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.savefig("task6_period_scan.png", dpi=200, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
