"""
MECH2700 Assignment 2, Task 5: baseline contour plots and grid-refinement study.
 
Uses run_simulation() from A2_Task_4.py. Rotation period 1000 s, t_max = 7200 s.
Grids: (dx, dy) = coarse, coarse/2, coarse/4.
"""

import time 
import matplotlib.pyplot as plt
import numpy as np 

import A2_Task_4 as ow

OMEGA = 2 * np.pi / 1000.0   # rad/s
T_MAX = 7200.0
T_PLOT = T_MAX / 5

# Coarse grid: dx = h/16 (nx = 17), dy ~ 0.1 m (ny = 159).
# Refining spacings by a factor f means (n - 1) is multiplied by f.
NXO, NYO = 17, 159
FACTORS = [1, 2, 4]

def grid_sizes(f):
    return (NXO - 1) * f + 1, (NYO - 1) * f + 1

def plot_contours(res, fname):
    """Contour plots of T(x, y) at each stored snapshot (different axis scales)."""
    n = len(res["t_snap"])
    fig, axes = plt.subplots(n, 1, figsize=(8, 2.0 *n), sharex=True)
    vmin = min(T.min() for T in res["T_snap"])
    vmax = max(T.max() for T in res["T_snap"])
    for ax, t, T in zip(axes, res["t_snap"], res["T_snap"]):
        cs = ax.contourf(res["y"], res["x"]* 1e3, T, levels=20, vmin=vmin, vmax=vmax, cmap="inferno")
        ax.invert_yaxis()
        ax.set_ylabel("x (mm)")
        ax.set_title(f"t = {t:.0f} s", fontsize=9, loc="left")
    axes[-1].set_xlabel("y (m)")
    fig.colorbar(cs, ax=axes, label="Temperature (K)")
    fig.suptitle("Wall temperature distribution (coarse grid,  "
                 r"$\omega = 2\pi/1000$ rad/s)")
    fig.savefig(fname, dpi=200, bbox_inches="tight")
    plt.close(fig)

def main():
    results = {}
    for f in FACTORS:
        nx, ny = grid_sizes(f)
        t0 = time.perf_counter()
        res = ow.run_simulation(nx, ny, OMEGA, T_MAX, T_PLOT)
        res["runtime"]= time.perf_counter() - t0
        res["nx"], res["ny"] = nx, ny
        results[f] = res

    # table
    print(f"{'factor':>6} {'nx':>4} {'ny':>5} {'dx (mm)':>9} {'dy (m)':>8} "
          f"{'dt (s)':>8} {'steps':>7} {'runtime (s)':>12} "
          f"{'peak Tw,max (K)':>16} {'Tw,max(tmax) (K)':>17}")

    for f, r in results.items():
     print(f"{f:>6} {r['nx']:>4} {r['ny']:>5} {r['dx']*1e3:>9.4f} "
              f"{r['dy']:>8.4f} {r['dt']:>8.4f} {len(r['t_hist'])-1:>7} "
              f"{r['runtime']:>12.2f} {r['Tw_max_hist'].max():>16.4f} "
              f"{r['Tw_max_hist'][-1]:>17.4f}")

    # contour plots
    plot_contours(results[1], "task5_contours.png")

    # Tw,max history for the coarse grid
    r = results[1]
    fig, ax = plt.subplots(figsize=(7,4))
    ax.plot(r["t_hist"], r["Tw_max_hist"])
    ax.set_xlabel("Time (s)")
    ax.set_ylabel(r"$T_{w,max}$ (K)")
    ax.set_title("Maximum inner-wall temperature (coarse grid)")
    ax.grid(alpha=0.3)
    fig.savefig("task5_Twmax_coarse.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    # Grid comparision of Tw,max histories
    fig, ax = plt.subplots(figsize=(7,4))
    for f, r in results.items():
        ax.plot(r["t_hist"], r["Tw_max_hist"], label=rf"$\Delta x = h/{16 *f}$, $\Delta y = {r['dy']:.3f}$m")

    ax.set_xlabel("Time (s)")
    ax.set_ylabel(r"$T_{w,max}$ (K)")
    ax.set_title("Grid dependence of the maximum inner-wall temperature")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.savefig("task5_grid_comparision.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

if __name__ == "__main__":
    main()